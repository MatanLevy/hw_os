

#include <stdio.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h> // for open flags
#include <unistd.h>
#include <time.h> // for time measurement
#include <sys/time.h>
#include <assert.h>
#include <errno.h>
#include <string.h>


#define KB 1024
#define SECTORS_PER_BLOCK 4
#define BLOCK_SIZE 4*KB


char buffer[BLOCK_SIZE];
int num_dev;
int *dev_status;
int numberOfFaultyDevices;

void writeToBuffer() {
	for (int i = 0; i < BLOCK_SIZE; i++)
		buffer[i] = 1;
}

int seekOffset(off_t offset, int dev_num) {
	off_t new_offset = lseek(dev_status[dev_num], (off_t)offset, SEEK_SET);
	if (new_offset < 0) {
		numberOfFaultyDevices++;
		printf("error calculationg offset %s\n", strerror(errno));
		dev_status[dev_num] = -1;
		close(dev_status[dev_num]);
		return -1;
	}
	else
		return 1;
}

int readFromDevice(int dev_num) {
	if (read(dev_status[dev_num], buffer, BLOCK_SIZE) < 0) {
		numberOfFaultyDevices++;
		dev_status[dev_num] = -1;
		close(dev_status[dev_num]);
		printf("error wirh read %s\n", strerror(errno));
		return -1;
	}
	return 1;
}

int writeToDevice(int dev_num) {
	if (write(dev_status[dev_num], buffer, BLOCK_SIZE) < 0) {
		numberOfFaultyDevices++;
		printf("error write %s\n", strerror(errno));
		close(dev_status[dev_num]);
		dev_status[dev_num] = -1;
	}
}

int restartRead(int dev_num, off_t offset, int sector_phys) {
	for (int i = 0; i < num_dev; i++) {
		if (i == dev_num)
			continue;
		if (dev_status[i] != -1) {
			if (seekOffset(offset, i) > 0)
				if (readFromDevice(i) > 0)
					printf("Operation on device %d, sector %d\n", i, sector_phys);
				else {
					printf("Operation on bad device %d\n", i);   
					dev_status[i] = -1;
					return -1;
				}
			else {
				printf("Operation on bad device %d\n", i);
				dev_status[i] = -1;
				return -1;
			}
		}
		else {
			printf("Operation on bad device %d\n", i);
			return -1;
		}
	}
}

int readWithBadDisk(int dev_num, int offset, int sector_phys) {

	//if i have at least 2 faulty  devices i immidiately can print operation on bad device
	//on the current device,as i asked in the forum
	// http://moodle.tau.ac.il/mod/forum/discuss.php?d=51147
	if (numberOfFaultyDevices > 1)
		printf("Operation on bad device %d\n", dev_num);   
	else {
		if (restartRead(dev_num, offset, sector_phys) > 0)
			return 1;
	}
	return -1;
}

int writeWithBadDisk(int dev_num, int offset, int sector_phys, int pairty_index) {
	if (readWithBadDisk(dev_num, offset, sector_phys) > 0)
		if (writeToDevice(pairty_index) > 0) {
			printf("Operation on device %d, sector %d\n", pairty_index, sector_phys);
			return 1;
		}
		else {
			printf("Operation on bad device %d\n", pairty_index);
			return -1;
		}
		return -1;
}



void do_raid5(int sector_log, char* cmd, char** argv) {



	int line_number = sector_log / (SECTORS_PER_BLOCK * (num_dev - 1));
	int pairty_index = num_dev - 1 - (line_number % num_dev);
	int dev_num = (sector_log / SECTORS_PER_BLOCK) % (num_dev - 1);
	dev_num = (dev_num >= pairty_index) ? dev_num + 1 : dev_num;
	int sector_phys = line_number * SECTORS_PER_BLOCK
		+ (sector_log % SECTORS_PER_BLOCK);
	int offset = BLOCK_SIZE*sector_phys;

	int pairty_valid = (dev_status[pairty_index] == -1) ? -1 : 1;

	if (!strcmp("READ", cmd)) {
		if (dev_status[dev_num] != -1) {  //disk is not faulty
			if (seekOffset(offset, dev_num) > 0) {
				if (readFromDevice(dev_num) > 0) {
					printf("Operation on device %d, sector %d\n", dev_num, sector_phys);
					return;
				}
			}
		}
		//if we reach here we have at least one bad disk
		readWithBadDisk(dev_num, offset, sector_phys);

	}
	else if (!strcmp("WRITE", cmd)) {
		if (dev_status[dev_num] != -1) {
			if (pairty_valid < 0) { //only write
				if (seekOffset(offset, dev_num) > 0)
					if (writeToDevice(dev_num) > 0) {
						printf("Operation on device %d, sector %d\n", dev_num, sector_phys);
						return;
					}
				restartRead(dev_num, offset, sector_phys);
			} //else should read and write to disk and then to pairty
			else {
				if (seekOffset(offset, dev_num) > 0)
					if (readFromDevice(dev_num) > 0) {
						printf("Operation on device %d, sector %d\n", dev_num, sector_phys);
						if (writeToDevice(dev_num) > 0) {
							printf("Operation on device %d, sector %d\n", dev_num, sector_phys);
							if (readFromDevice(pairty_index) > 0) {
								printf("Operation on device %d, sector %d\n", pairty_index, sector_phys);
								if (writeToDevice(pairty_index) > 0) {
									printf("Operation on device %d, sector %d\n", pairty_index, sector_phys);
									return;
								}
								printf("Operation on bad device %d\n", pairty_index);
								return;
							}
							printf("Operation on bad device %d\n", pairty_index);
							return;
						}
					}
				writeWithBadDisk(dev_num, offset, sector_phys, pairty_index);
			}
		}
		else { //should read from all disks other than dev_num and then should write to pairty. 
			writeWithBadDisk(dev_num, offset, sector_phys, pairty_index);
		}
	}
	//here actually is the dev_num and not sector log
	else if (!strcmp("REPAIR", cmd)) {
		int fd = open(argv[sector_log+1], O_RDWR, S_IRWXO);
		if (fd < 0) {
			printf("problem with open %s\n", strerror(errno));
			printf("Operation on bad device %d\n", dev_num);
		}
		else {
			if (dev_status[sector_log] != -1)
				close(dev_status[sector_log]);
			else
				numberOfFaultyDevices--;


			dev_status[sector_log] = fd;
		}

	}
	//here actually is the dev_num and not sector log
	else if (!strcmp("KILL", cmd)) {
		if (dev_status[sector_log] != -1) {
			close(dev_status[sector_log]);
			dev_status[sector_log] = -1;
			numberOfFaultyDevices++;
		}

	}
}
int main(int argc, char** argv)
{
	int i;
	int fd;
	char line[1024];
	writeToBuffer();
	num_dev = argc - 1;
	int _dev_status[num_dev];
	dev_status = _dev_status;
	numberOfFaultyDevices = 0;
	for (int i = 1; i < argc; i++) {
		fd = open(argv[i], O_RDWR, S_IRWXO);
		if (fd < 0) {
			numberOfFaultyDevices++;
			printf("Error opening file : %s\n", strerror(errno));
			dev_status[i - 1] = -1; //KILL
		}
		else
			dev_status[i - 1] = fd;
	}
	char cmd[20];
	int param;
	while (fgets(line, 1024, stdin) != NULL) {
		sscanf(line, "%s %d", cmd, &param);
		do_raid5(param, cmd, argv);
	}
	for (int i = 0; i < num_dev; i++)
		if (dev_status[i] != -1)
			close(dev_status[i]);
}