

#define _GNU_SOURCE
#include <stdio.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <fcntl.h> // for open flags
#include <unistd.h>
#include <time.h> // for time measurement
#include <sys/time.h>
#include <assert.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdlib.h>
#include <math.h>



int** mat;// the matrix;
int** helper; //helper matrix;


int countLiveNeighbors(int** mat,int i,int j,int size) {
	int counter=0;
	if (i == 0 && j == 0)
		return mat[i][j+1]+mat[i+1][j]+mat[i+1][j+1];
	if (i == 0 && j == size-1)
		return mat[i][j-1]+mat[i+1][j-1]+mat[i+1][j];
	if (i == size-1 && j == 0)
		return mat[i-1][j]+mat[i][j+1]+mat[i-1][j+1];
	if (i==size-1 && j==size-1)
		return mat[i][j-1]+mat[i-1][j]+mat[i-1][j-1];
	if (i==0)
		return mat[i][j-1]+mat[i][j+1]+mat[i+1][j]+mat[i+1][j-1]+mat[i+1][j+1];
	if (i==size-1)
		return mat[i][j-1]+mat[i][j+1]+mat[i-1][j]+mat[i-1][j-1]+mat[i-1][j+1];
	if (j==0)
		return mat[i-1][j]+mat[i+1][j]+mat[i-1][j+1]+mat[i][j+1]+mat[i+1][j+1];
	if (j==size-1)
		return mat[i-1][j]+mat[i+1][j]+mat[i-1][j-1]+mat[i][j-1]+mat[i+1][j-1];
	return mat[i-1][j-1]+mat[i-1][j]+mat[i-1][j+1]+mat[i][j-1]+mat[i][j+1]+mat[i+1][j-1]+mat[i+1][j]+mat[i+1][j+1];
}

void makeMove(int size,int** A,int** B) {
	for (int i=0;i<size;i++)
		for(int j=0;j<size;j++) {
			int liveN=countLiveNeighbors(A,i,j,size);
			if (A[i][j] && liveN < 2)
				B[i][j]=0;
			else if (A[i][j] && liveN > 3)
				B[i][j]=0;
			else if(!A[i][j] && liveN == 3)
				B[i][j]=1;
			else
				B[i][j]=A[i][j];
		}
}

void printMatrix(int size) {
	for(int x = 0; x < size; ++x)
		{
			for(int y = 0; y < size; ++y)
			{
				printf("%d", mat[x][y]);
			}
			printf("\n");
		} 
}

int fillMatrix(char* filename) {
	int fd=open(filename,O_RDWR,S_IRWXO);
	if (fd < 0) {
		printf("problem with opening file : %s\n",strerror(errno));
		return -1;
	}
	//CREDIT : http://stackoverflow.com/questions/8236/how-do-you-determine-the-size-of-a-file-in-c
	struct stat st;
	if (stat(filename,&st) < 0) {
		printf("problem with stat : %s \n",strerror(errno));
		return -1;
	}
	int size_file=st.st_size;
	int SIZE=(int)sqrt(size_file);

	mat = (int**) malloc(sizeof(int*) * SIZE);
	if (mat == NULL)
		printf("malloc failed : %s\n",strerror(errno));
	for (int i = 0; i < SIZE; ++i) {
		mat[i] = (int*) malloc(sizeof(int) * SIZE);
		if (mat[i] == NULL)
			printf("malloc failed %s\n",strerror(errno));
	}

	helper = (int**) malloc(sizeof(int*) * SIZE);
	if (helper == NULL)
		printf("malloc failed %s\n",strerror(errno));
	for (int i = 0; i < SIZE; ++i) {
		helper[i] = (int*) malloc(sizeof(int) * SIZE);
		if (helper[i] == NULL)
			printf("malloc failed %s\n",strerror(errno));
	}
	char buffer[1024];

	int i=0;int j=0;int cnt=0;int cnt1=0;

	while (cnt1 < size_file) {
		int number_to_read=(size_file < 1024) ? size_file : 1024;
		cnt1+=number_to_read;
		if (read(fd,buffer,number_to_read) < 0) {
			printf("error with read : %s\n",strerror(errno));
			return -1;
		}
		cnt=0;
		while (cnt<number_to_read) {
			mat[j][i]=buffer[cnt++] ? 1 : 0;
			if (j != (SIZE-1)) {
				j++;
			}
			else {
				j=0;
				i++;
			}
		}
	}
	close(fd);	
	return SIZE;
}
 

int main(int argc,char** argv) {
	struct timeval start, end;
	long mtime, seconds, useconds;
	char*  filename=argv[1];
	int steps=strtol(argv[2],NULL,10);
	int size = fillMatrix(filename);
	if (size < 0) {
		return 1;
	}	
	if (gettimeofday(&start, NULL) != 0) {
		printf("Error getting time: %s\n", strerror(errno));
		return -1;
	}
	for (int i=0;i<steps;i++) {
		(i % 2) ? makeMove(size,helper,mat) : makeMove(size,mat,helper);

	}
	if (steps % 2) { //should make another step
		int** temp=mat;
		mat=helper; 
		helper=temp;
	}
	if (gettimeofday(&end, NULL) != 0) {
		printf("Error getting time: %s\n", strerror(errno));
		return -1;
	}
	seconds = end.tv_sec - start.tv_sec;
	useconds = end.tv_usec - start.tv_usec;
	mtime = (seconds * 1000 + useconds / 1000.0);
	printf("seconds = %ld mtime = %ld\n", seconds,mtime);
	for (int i=0;i<size;i++)
		free(mat[i]);
	free(mat);
	for (int i=0;i<size;i++)
		free(helper[i]);
	free(helper);

}