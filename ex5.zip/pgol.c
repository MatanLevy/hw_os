#define _GNU_SOURCE
#include <stdio.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <fcntl.h> // for open flags
#include <unistd.h>
#include <time.h> // for time measurement
#include <sys/time.h>
#include <assert.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdlib.h>
#include <math.h>
#include <pthread.h>


//i didnt check return value of lock,unlock as stated in the forum

pthread_mutex_t qlock,lock,wlock;
pthread_cond_t notEmpty,finishTask;
long counter=0;
int stepNumber=0;
long size=0;
typedef struct elem {
	int x,y,dx,dy;
} Task;

typedef struct node {
	Task info;
	struct node* next;
} QueueNode;

QueueNode* front=NULL;
QueueNode* end=NULL;

int mal=0;
int fre=0;


void Enqueue1(Task t1) {
	int rc;
	pthread_mutex_lock(&qlock);
	QueueNode* temp1=(QueueNode*)malloc(sizeof(QueueNode));
	if (temp1 == NULL) {
		printf("malloc failed : %s\n",strerror(errno));
		exit(1);
	}
	temp1->info=t1; 
	temp1->next=NULL;
	if (front==NULL && end==NULL) { //queue is empty
		front=temp1;
		end=temp1;
	}
	//else queue is not empty
	else {
	end->next=temp1;
	end=temp1;
	}
	if (rc=pthread_cond_signal(&notEmpty) != 0) {
		printf("error with signal : %s\n",strerror(rc));
		exit(1);
	}
	pthread_mutex_unlock(&qlock);
}

void Enqueue(Task t1,Task t2,Task t3,Task t4) {
	int rc;
	pthread_mutex_lock(&qlock);
	QueueNode* temp1=(QueueNode*)malloc(sizeof(QueueNode));
	if (temp1 == NULL) {
		printf("malloc failed : %s\n",strerror(errno));
		exit(1);
	}
	QueueNode* temp2=(QueueNode*)malloc(sizeof(QueueNode));
	if (temp2 == NULL) {
		printf("malloc failed : %s\n",strerror(errno));
		exit(1);
	}
	QueueNode* temp3=(QueueNode*)malloc(sizeof(QueueNode));
	if (temp3 == NULL) {
		printf("malloc failed  : %s\n",strerror(errno));
		exit(1);
	}
	QueueNode* temp4=(QueueNode*)malloc(sizeof(QueueNode));
	if (temp4 == NULL) {
		printf("malloc failed %s\n",strerror(errno));
		exit(1);
	}
	temp1->info=t1;
	temp2->info=t2;
	temp3->info=t3;
	temp4->info=t4;
	temp4->next=temp3;
	temp3->next=temp2;
	temp2->next=temp1;
	temp1->next=NULL;
	if (front==NULL && end==NULL) { //queue is empty
		front=temp4;
		end=temp1;
	}
	//else queue is not empty
	else {
	end->next=temp4;
	end=temp1;
	}
	if (rc=pthread_cond_signal(&notEmpty) != 0) {
		printf("error with signal : %s \n",strerror(rc));
		exit(1);
	}
	pthread_mutex_unlock(&qlock);
}
Task dequeue() {
	int rc;
	pthread_mutex_lock(&qlock);
	while (front==NULL && end==NULL) {
		if (rc=pthread_cond_wait(&notEmpty,&qlock) != 0) {
			printf("error with wait : %s\n",strerror(rc));
		}
	}
	QueueNode* temp=front;
	Task t=front->info;
	if (front==end) {
		front=end=NULL;
	}
	else {
		front=front->next;
	}
	free(temp);
	pthread_mutex_unlock(&qlock);
	return t;
}


int** mat;// the matrix;
int** helper; //helper matrix;


int countLiveNeighbors(int** mat,int i,int j,int size) {
	int counter=0;
	if (i == 0 && j == 0)
		return mat[i][j+1]+mat[i+1][j]+mat[i+1][j+1];
	if (i == 0 && j == size-1)
		return mat[i][j-1]+mat[i+1][j-1]+mat[i+1][j];
	if (i == size-1 && j == 0)
		return mat[i-1][j]+mat[i][j+1]+mat[i-1][j+1];
	if (i==size-1 && j==size-1)
		return mat[i][j-1]+mat[i-1][j]+mat[i-1][j-1];
	if (i==0)
		return mat[i][j-1]+mat[i][j+1]+mat[i+1][j]+mat[i+1][j-1]+mat[i+1][j+1];
	if (i==size-1)
		return mat[i][j-1]+mat[i][j+1]+mat[i-1][j]+mat[i-1][j-1]+mat[i-1][j+1];
	if (j==0)
		return mat[i-1][j]+mat[i+1][j]+mat[i-1][j+1]+mat[i][j+1]+mat[i+1][j+1];
	if (j==size-1)
		return mat[i-1][j]+mat[i+1][j]+mat[i-1][j-1]+mat[i][j-1]+mat[i+1][j-1];
	return mat[i-1][j-1]+mat[i-1][j]+mat[i-1][j+1]+mat[i][j-1]+mat[i][j+1]+mat[i+1][j-1]+mat[i+1][j]+mat[i+1][j+1];
}

void makeMove(int size,int** A,int** B) {
	for (int i=0;i<size;i++)
		for(int j=0;j<size;j++) {
			int liveN=countLiveNeighbors(A,i,j,size);
			if (A[i][j] && liveN < 2)
				B[i][j]=0;
			else if (A[i][j] && liveN > 3)
				B[i][j]=0;
			else if(!A[i][j] && liveN == 3)
				B[i][j]=1;
			else
				B[i][j]=A[i][j];
		}
}

void printMatrix(long size) {
	for(int x = 0; x < size; ++x)
		{
			for(int y = 0; y < size; ++y)
			{
				printf("%d", mat[x][y]);
			}
			printf("\n");
		} 
}

long fillMatrix(char* filename) {
	int fd=open(filename,O_RDWR,S_IRWXO);
	if (fd < 0) {
		printf("problem with opening file : %s\n",strerror(errno));
		return -1;
	}
	//CREDIT : http://stackoverflow.com/questions/8236/how-do-you-determine-the-size-of-a-file-in-c
	struct stat st;
	if (stat(filename,&st) < 0) {
		printf("problem with stat : %s \n",strerror(errno));
		return -1;
	}
	int size_file=st.st_size;
	int SIZE=(int)sqrt(size_file);

	mat = (int**) malloc(sizeof(int*) * SIZE);
	if (mat == NULL) {
		printf("malloc failed : %s\n",strerror(errno));
		exit(1);
	}
	for (int i = 0; i < SIZE; ++i) {
		mat[i] = (int*) malloc(sizeof(int) * SIZE);
		if (mat[i] == NULL) {
			printf("malloc failed : %s\n",strerror(errno));
			exit(1);
		}
	}

	helper = (int**) malloc(sizeof(int*) * SIZE);
	if (helper == NULL) {
		printf("malloc failed : %s\n",strerror(errno));
		exit(1);
	}
	for (int i = 0; i < SIZE; ++i) {
		helper[i] = (int*) malloc(sizeof(int) * SIZE);
		if (helper[i] == NULL) {
			printf("malloc failed : %s\n",strerror(errno));
			exit(1);
		}
	}
	char buffer[1024];

	int i=0;int j=0;int cnt=0;int cnt1=0;

	while (cnt1 < size_file) {
		int number_to_read=(size_file < 1024) ? size_file : 1024;
		cnt1+=number_to_read;
		if (read(fd,buffer,number_to_read) < 0) {
			printf("error with read : %s\n",strerror(errno));
			return -1;
		}
		cnt=0;
		while (cnt<number_to_read) {
			mat[j][i]=buffer[cnt++] ? 1 : 0;
			if (j != (SIZE-1)) {
				j++;
			}
			else {
				j=0;
				i++;
			}
		}
	}
	close(fd);	
	return SIZE;
}
void executeTask(Task task,int stepNumber,int size) {
	int rc;
	if (task.dx !=1 && task.dy!=1) {
		Task t1={task.x,task.y,task.dx/2,task.dy/2};
		Task t2={task.x+task.dx/2,task.y+task.dy/2,task.dx/2,task.dy/2};
		Task t3={task.x+task.dx/2,task.y,task.dx/2,task.dy/2};
		Task t4={task.x,task.y+task.dy/2,task.dx/2,task.dy/2};
		Enqueue(t1,t2,t3,t4); 
	}
		else {
			(stepNumber % 2) ? makeMove(size,helper,mat) : makeMove(size,mat,helper);
			__sync_fetch_and_add(&counter, 1);
			if (counter == size*size) 
				if (rc=pthread_cond_broadcast(&finishTask) != 0) {
					printf("error with broadcast :%s\n",strerror(rc));
				}
		}
}
//run function for all threads
void* run(void* x) {
	while (1) {
		Task task=dequeue();
		executeTask(task,stepNumber,size);
	}
}


int main(int argc,char** argv) {
	struct timeval start, end;
	long mtime, seconds, useconds;
	int rc;
	if (pthread_cond_init(&notEmpty,NULL) < 0) {
		printf("error with thread : %s\n",strerror(errno));
		return 1;
	}
	if (pthread_cond_init(&finishTask,NULL) < 0) {
		printf("error with thread : %s\n",strerror(errno));
		return 1;
	}
	if (pthread_mutex_init(&qlock,NULL) < 0) {
		printf("error creating mutex : %s\n",strerror(errno));
		return 1;
	}
	if (pthread_mutex_init(&lock,NULL) < 0) {
		printf("error creating mutex : %s\n",strerror(errno));
		return 1;
	}
	char*  filename=argv[1];
	int steps=strtol(argv[2],NULL,10);
	size = fillMatrix(filename);
	if (size < 0) {
		return 1;
	}	
	int threads=strtol(argv[3],NULL,10);
	pthread_t thread[threads];
	for(int t=0; t<threads; t++)
	{
		rc = pthread_create(&thread[t], NULL, run,NULL); 
		if (rc) {
			printf("ERROR in pthread_create(): %s\n", strerror(rc));
			exit(-1);
		}
	}
	if (gettimeofday(&start, NULL) != 0) {
		printf("Error getting time: %s\n", strerror(errno));
		return -1;
	}
	for(int i=0;i<steps;i++) {
		stepNumber=i;
		Task t1={0,0,size,size};
		Enqueue1(t1);
		if (rc=pthread_mutex_lock(&lock) != 0) {
			printf("error : %s\n",strerror(rc));
		}
		//while (counter < size*size) 
			pthread_cond_wait(&finishTask,&lock);
		
		if (rc=pthread_mutex_unlock(&lock) != 0) {
			printf("error : %s\n",strerror(rc));
		}
		counter=0;
	}
	if (steps % 2) { //should make another step
		int** temp=mat;
		mat=helper;
		helper=temp;
	}
	if (gettimeofday(&end, NULL) != 0) {
		printf("Error getting time: %s\n", strerror(errno));
		return -1;
	}
	seconds = end.tv_sec - start.tv_sec;
	useconds = end.tv_usec - start.tv_usec;
	mtime = (seconds * 1000 + useconds / 1000.0);
	printf("seconds = %ld mtime = %ld\n", seconds,mtime);
	void* status;
	for(int t=0; t<threads; t++) {
		rc = pthread_cancel(thread[t]);
		if (rc) {
			printf("ERROR in pthread_cancel(): %s\n", strerror(rc));
			exit(-1);
		}
	}
	for (int i=0;i<size;i++)
		free(mat[i]);
	free(mat);
	for (int i=0;i<size;i++)
		free(helper[i]);
	free(helper);
	if (rc=pthread_cond_destroy(&notEmpty) != 0) {
		printf("error destroy notEmpty %s\n",strerror(rc));
		return 1; 
	}
	if (rc=pthread_cond_destroy(&finishTask) != 0) {
		printf("error destroy finishTask %s\n",strerror(rc));
		return 1;
	}
	if (rc=pthread_mutex_destroy(&lock) != 0) {
		printf("error destroy mutex mainLock : %s\n",strerror(rc));
		return 1;
	}
	if (rc=pthread_mutex_destroy(&qlock) != 0) {
		printf("error destroy mutex QueueLock : %s\n",strerror(rc));
		return 1;
	}
	return 1;
}