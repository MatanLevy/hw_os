
#define _GNU_SOURCE
#include <stdio.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h> // for open flags
#include <unistd.h>
#include <time.h> // for time measurement
#include <sys/time.h>
#include <assert.h>
#include <errno.h>
#include <string.h>

#define  XSIZE (1024* KB)

#define DIRECT 1

#define KB 1024
#define MB 1048576

void writeToBuffer(char* buffer, int size) {
	int i;
	for (i = 0; i < size; i++)
		buffer[i] = random();
}

int main(int argc, char** argv) {
	struct timeval start, end;
	long mtime, seconds, useconds;
	struct stat buff;
	int file_exist;
	int fd;
	long i;
	static char buf[1024 * 1024] __attribute__ ((__aligned__ (4096)));
	writeToBuffer(buf,1 * MB);
	if ((file_exist = stat(argv[1], &buff)) < 0)
		printf("Input file does not exist\n");
	else {
		printf("Input file exsits\n");
		if (S_ISREG(buff.st_mode))
			printf("It is a regular file\n");
		else if   (S_ISDIR(buff.st_mode))
			printf("It is a directory\n");
		else
			printf("Not a regular file or directory\n");
		if (!S_ISREG(buff.st_mode)) {
			printf("Not a regular file\n");
			return -1;
		}
	}

	if (file_exist != -1) {
		if (buff.st_size != 256 * MB) {
			fd = open(argv[1], O_TRUNC | O_RDWR, S_IRWXU);
			if (fd < 0) {
				printf("Error opening file : %s\n", strerror(errno));
				return 1;
			}
			for (i = 0; i < 256; i++) {
				writeToBuffer(buf, 1 * MB);
				if (write(fd, buf, 1 * MB) < 0) {
					printf("Error writing to file: %s\n", strerror(errno));
					return 1;
				}
			}
			if (close(fd)<0) {          
			    printf("error closing file : %s\n",strerror(errno));
			    return -1;
			}
		}
	} else {
		fd = creat(argv[1], O_RDWR | S_IRWXU);
		if (fd < 0) {
			printf("Error opening file : %s\n", strerror(errno));
			return 1;
		}
		for (i = 0; i < 256; i++) {
			writeToBuffer(buf, 1 * MB);
			if (write(fd, buf, 1 * MB) < 0) {
				printf("Error writing to file: %s\n", strerror(errno));
				return 1;
			}
		}
		if (close(fd)<0) {          
		    printf("error closing file : %s\n",strerror(errno));
		    return -1;
		}

	}
	
	int XSize = XSIZE;
	if (gettimeofday(&start, NULL) != 0) {
		printf("Error getting time: %s\n", strerror(errno));
		return -1;
	}
	fd =  (DIRECT == 1)  ? open(argv[1], O_RDWR | O_DIRECT, S_IRWXU) : open(argv[1],O_RDWR , S_IRWXU);
	if (fd < 0) {
		printf("Error opening  file: %s\n", strerror(errno));
		return 1;
	}
	for (i = 0; i < 256 * 1024 * 1024 / XSize; ++i) {
		int modulu = (256 * MB) / XSize;
		int offset = (random() % modulu) * XSize;
		off_t new_offset = lseek(fd, (off_t) offset, SEEK_SET);
		if (new_offset < 0) {
			printf("Error calculating offset in file :%s\n", strerror(errno));
			return 1;
		}
		write(fd, buf, XSIZE);
		if (fd < 0) {
			printf("Error writing to file: %s\n", strerror(errno));
			return 1;
		}
	}
	close(fd);

	if (gettimeofday(&end, NULL) != 0) {
		printf("Error getting time: %s\n", strerror(errno));
		return -1;

	}
	seconds = end.tv_sec - start.tv_sec;
	useconds = end.tv_usec - start.tv_usec;
	mtime = (seconds * 1000 + useconds / 1000.0);
	double throughput = ((double) (256 * 1000) / mtime);
	printf("throughput = %lf\n", throughput); 

}
