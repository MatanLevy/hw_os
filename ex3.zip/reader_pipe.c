#define _GNU_SOURCE
#include <stdio.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h> // for open flags
#include <unistd.h>
#include <time.h> // for time measurement
#include <sys/time.h>
#include <assert.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include <stdlib.h>

void sleepUntilExist(char* filename, struct stat* buff) {
	while (stat(filename, buff) < 0) {
		if (errno == ENOENT)
			sleep(1);
		else {
			printf("error stat : %s\n", strerror(errno));
			exit(1);
		}
	}
}


int main(int argc, char** argv) {
	char line[256];
	int fd;
	int file_exist;
	struct stat buff;
	int readCheck;
	struct sigaction sig;
	struct sigaction old;
	if (sigemptyset(&sig.sa_mask) < 0) {
		printf("error with signal : %s\n", strerror(errno));
		return 1;
	}
	sig.sa_handler = SIG_IGN;
	while (1) {
		sleepUntilExist(argv[1], &buff);
		if (!S_ISFIFO(buff.st_mode)) {
			printf("file exists but not a fifo file \n");
			return 1;
		}
		fd = open(argv[1], O_RDONLY, S_IRWXU);
		if (fd < 0) {
			if (errno == ENOENT)
				continue;
			printf("error opening file : %s\n", strerror(errno));
			return 1;
		}
		if (sigaction(SIGINT, &sig, &old) < 0) {
			printf("problem with signal : %s\n", strerror(errno));
			return 1;
		}
		if (sigaction(SIGTERM, &sig, &old) < 0) {
			printf("problem with signal : %s\n", strerror(errno));
			return 1;
		}
		while (readCheck = read(fd, line, 256) != 0) {
			if (readCheck < 0) {
				printf("problem with read : %s\n", strerror(errno));
				return 1;
			}
			printf("%s", line);
		}
		close(fd);

		if (sigaction(SIGINT, &old, NULL) < 0) {
			printf("problem with signal : %s\n", strerror(errno));
			return 1;
		}
		if (sigaction(SIGTERM, &old, NULL) < 0) {
			printf("problem with signal : %s\n", strerror(errno));
			return 1;
		}
	}
}