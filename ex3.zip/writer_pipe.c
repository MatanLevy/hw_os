
#define _GNU_SOURCE
#include <stdio.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h> // for open flags
#include <unistd.h>
#include <time.h> // for time measurement
#include <sys/time.h>
#include <assert.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include <stdlib.h>

int fd;
char* fileName;
int canRunAfterFixPipe;

int createFifo(char* filename) {
	if (mkfifo(filename, S_IWUSR | S_IRUSR |
		S_IRGRP | S_IROTH) < 0) {
		printf("error create fifo :  %s\n", strerror(errno));
		return -1;
	}
	else {
		fd = open(filename, O_WRONLY, S_IRWXU);
		if (fd < 0) {
			printf("error opening file : %s\n", strerror(errno));
			return -1;
		}
	}
	return fd;
}


void signalHandlerFinishing(int sigNumber) {
	if (sigNumber == SIGINT || sigNumber == SIGTERM) {
		if (unlink(fileName) < 0) {
			printf("error with unlink : %s\n", strerror(errno));
			exit(1);
		}
		close(fd);
		exit(1);
	}
	else
		printf("not the correct signal\n");
}
void signalHandlerPipe(int sigNumber) {
if (sigNumber == SIGPIPE) {
		printf("writing to closed pipe\n");
		close(fd);
		fd = open(fileName, O_WRONLY, S_IRWXU);
		if (fd < 0) {
			printf("problem opening file : %s\n", strerror(errno));
			exit(1);
		}
		canRunAfterFixPipe = 1;
	}
	else
		printf("not the correct signal\n");
}
int main(int argc,char** argv) {
	canRunAfterFixPipe = 0;
	int file_exist;
	struct stat buff;
	char line[256];
	fileName = argv[1];
	struct sigaction sig1, sig2;
	// http://stackoverflow.com/questions/20684290/signal-handling-and-sigemptyset
	if (sigemptyset(&sig1.sa_mask) < 0) {
		printf("error init signal : %s\n", strerror(errno));
		return 1;
	}
	if (sigemptyset(&sig2.sa_mask) < 0) {
		printf("error init signal : %s\n", strerror(errno));
		return 1;
	}
	//https://gist.github.com/aspyct/3462238
	sig1.sa_handler = &signalHandlerFinishing;
	sig2.sa_handler = &signalHandlerPipe;

	if (sigaction(SIGINT, &sig1, NULL) < 0) {
		printf("problem with signal : %s\n", strerror(errno));
		return 1;
	}
	if (sigaction(SIGTERM, &sig1, NULL) < 0) {
		printf("problem with signal : %s\n", strerror(errno));
		return 1;
	}
	if (sigaction(SIGPIPE, &sig2, NULL) < 0) {
		printf("problem with signal : %s\n", strerror(errno));
		return 1;
	}


	if ((file_exist = stat(argv[1], &buff)) < 0) {
		fd = createFifo(argv[1]);
		if (fd < 0)
			return 1;
	}
	else {
		if (!S_ISFIFO(buff.st_mode)) {
			if (unlink(argv[1]) < 0) {
				printf("error with unlink : %s\n", strerror(errno));
				return 1;
			}
			fd = createFifo(argv[1]);
			if (fd < 0)
				return 1;
		}
		else {
			fd = open(argv[1], O_WRONLY, S_IRWXU);
			if (fd < 0) {
				printf("problem with open : %s\n",strerror(errno));
				return 1;
				}
			}
	}
	while (fgets(line, 256, stdin) != NULL) {
		if (write(fd, line, 256) < 0) {
			if (canRunAfterFixPipe)
				continue;
			printf("error with writing : %s\n", strerror(errno));
			return 1;
		}
	}
	if (unlink(argv[1]) < 0) {
		printf("error with unlink %s\n", strerror(errno));
		return 1;
	}
	close(fd);

}