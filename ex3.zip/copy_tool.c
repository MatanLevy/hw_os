
#define _GNU_SOURCE
#include <stdio.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <fcntl.h> // for open flags
#include <unistd.h>
#include <time.h> // for time measurement
#include <sys/time.h>
#include <assert.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char** argv) {
	long PAGE_SIZE = sysconf(_SC_PAGESIZE);
	char* source = argv[1];
	char* dest = argv[2];
	int fdSource, fdDest;
	fdSource = open(argv[1], O_RDWR, S_IRWXU);
	if (fdSource < 0) {
		printf("error opening file : %s\n", strerror(errno));
		return 1;
	}
	struct stat info;
	if (stat(argv[1], &info) < 0) {
		printf("error with stat : %s\n", strerror(errno));
		close(fdSource);
		return 1;
	}
	int size = info.st_size;
	fdDest = open(argv[2], O_RDWR, S_IRWXU);
	int newfile = 0;
	char *sourceArr, *destArr;
	if (fdDest < 0) {
		if (errno == ENOENT) {
			fdDest = open(argv[2],O_RDWR | O_CREAT, S_IRWXU);
			if (fdDest < 0) {
				close(fdSource);
				printf("error creating file : %s\n",strerror(errno));
				return 1;
			}
			newfile = 1;
		}
		else {
			printf("error opening file : %s\n", strerror(errno));
			close(fdSource);
			return 1;
		}
	}
	if (ftruncate(fdDest, size) < 0) {
		printf("problem with trunc : %s\n",strerror(errno));
		close(fdDest);
		close(fdSource);
		return 1;
	}
	int numberOfIter = (size / PAGE_SIZE)+1;
	for (int i = 0; i < numberOfIter; i++) {
		int offset = i*PAGE_SIZE;
		int remain = size - offset;
		int ammountToAlloc = PAGE_SIZE > remain ? remain : PAGE_SIZE;
		if (ammountToAlloc == 0)
			break;
		sourceArr = (char*)mmap(NULL, ammountToAlloc, PROT_READ | PROT_WRITE, MAP_SHARED, fdSource, offset);
		if (sourceArr == MAP_FAILED) {
			close(fdDest);
			close(fdSource);
			printf("Error mmapping the 1 file: %s\n", strerror(errno));
			return -1;
		}
		destArr = (char*)mmap(NULL, ammountToAlloc, PROT_WRITE | PROT_READ, MAP_SHARED, fdDest, offset);
		if (destArr == MAP_FAILED) {
			close(fdSource);
			close(fdDest);
			printf("Error mmapping the 2 file: %s  %d\n", strerror(errno), errno);
			return -1;
		}
		for (int j = 0; j < ammountToAlloc; j++) {
			destArr[j] = sourceArr[j];
		}
		int failProgramWithoutUnmapSource = 0;
		if (munmap(sourceArr, ammountToAlloc) == -1) {
			printf("Error un-mmapping the file: %s\n", strerror(errno));
			failProgramWithoutUnmapSource = 1;
		}
		if (munmap(destArr, ammountToAlloc) == -1 || (failProgramWithoutUnmapSource==1)) {
			printf("Error un-mmapping the file: %s\n", strerror(errno));
			close(fdDest);
			close(fdSource);
			return -1;
		}
	}
	close(fdDest);
	close(fdSource);

}