#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/wait.h> 
#include <unistd.h>

//golbal variable which used only for the first run
int firstrun = 0;
 
#define PIPE "|"
/*
signal handler for sigint only from child proccess. 
*/
void sigHand(int sigNumber) {
	if (sigNumber == SIGINT)
		exit(1);
}
/*
return the index of the pipe char if exist in command,else return zero
*/
int pipe_line(int count,char** arglist) {
	for (int i=1; i<count-1;i++) {
		if (!strcmp(arglist[i],PIPE))
			return i;
	}
	return 0;
}
//CREDIT : http://www.microhowto.info/howto/reap_zombie_processes_using_a_sigchld_handler.html	
//signal handler for sigchld to avoid zombies
void handle_sigchld(int sig) {
  while (waitpid((pid_t)(-1), 0, WNOHANG) > 0) {

  }
}


int process_arglist(int count, char** arglist) {
	pid_t child;
	int pipe_index;
	struct sigaction sig;		//signal handler for SIGINT only from child proccess
	struct sigaction sigchild;  //signal handler for SIGCHLD to prevent zombies
	struct sigaction old;       //old signal to restore before parent proccess ends

	if (sigemptyset(&sig.sa_mask) < 0) {
		printf("error with signal : %s\n", strerror(errno));
		return 0; 
	}
	sigchild.sa_handler = &handle_sigchld;
	if (sigemptyset(&sigchild.sa_mask) < 0) {
		printf("error with signal : %s\n",strerror(errno));
		return 0;
	}
	sigchild.sa_flags = SA_RESTART | SA_NOCLDSTOP;
	//old1 is the default handler for sigchild(only in the first call of the shell)
	if (sigaction(SIGCHLD, &sigchild, NULL) < 0) {
  		printf("error with signal : %s\n",strerror(errno));
  		return 0;
	}
	//save it in oldchild.
	if (firstrun == 0) { 
		firstrun++; //this will avoid putting bad handler in the next runs of the shell
	}
	//if the command is pipe
	if (pipe_index=pipe_line(count,arglist)) {
			arglist[pipe_index]=NULL; //in order to make two diffrent commands
			sig.sa_handler = &sigHand;
			if (sigaction(SIGINT,&sig,&old) < 0) {
				printf("error with signal : %s\n",strerror(errno));
				return 0;
			}
			child = fork();   //creating child proccess to run the command
			if (child < 0) {
				printf("fork failed : %s\n",strerror(errno));
				return 0;
			}
			if (child == 0) {       //insdine the child proccess-runing the command

				/*what i did here is to create another child proccess in order to run 2 command of the pipe

				*/
				int pipefd[2];
				if (pipe(pipefd) < 0) { 
					printf("error with pipe : %s\n",strerror(errno));
					return 0;
				}	
				pid_t child1=fork();
				if (child1 < 0) {
					printf("fork failed : %s\n",strerror(errno));
					return 0;
				}
				if (child1 > 0) {
					if (dup2(pipefd[0],STDIN_FILENO) < 0) { //replacing with sdtin for the pipe
						printf("error with dup2 : %s\n",strerror(errno));
						return 0;
					}
					close(pipefd[1]);
					int status;
					if (wait(&status) < 0) {
						printf("error with wait : %s\n",strerror(errno));
						return 0;
					}
					execvp(arglist[pipe_index+1],arglist+pipe_index+1); //runing the second coomand from child proccess
					printf("execvp failed : %s \n",strerror(errno)); 
					return 0;
				}
				else {
					if (dup2(pipefd[1],STDOUT_FILENO) < 0) {  //replacing with stdout for the pipe
						printf("error with dup2: %s\n",strerror(errno));
						return 0;
					}
					close(pipefd[0]);
					execvp(*arglist,arglist);    //runing the first command from parent proccess
					fprintf(stderr,"execvp failed : %s\n",strerror(errno)); //print to stderr because stdout is close
					return 0;
				}
			}
			//in the parent proccess we wait until the command(actually two commands) ends.and also ignoring SIGINT 
			//in order not to close our shell
			else {
				sig.sa_handler=SIG_IGN;
				if (sigaction(SIGINT,&sig,NULL) < 0) {
					printf("error with signal : %s\n",strerror(errno));
					return 0;
				}
				int status;
				if (wait(&status) < 0) {
					printf("error with wait 1: %s\n",strerror(errno));
					return 0;
				}
				if (sigaction(SIGINT,&old,NULL) < 0) {
					printf("error with signal : %s\n",strerror(errno));
					return 0;
				}
				return 1;
			}
	}
	//this is case of runing command in the background
	else if (!strcmp("&",arglist[count-1])) {
		child = fork();
		if (child == 0) {  // child proccess-run the command
			arglist[count-1]=NULL; //the actual command without &
			execvp(*arglist,arglist);
			printf("execvp failed : %s\n",strerror(errno));
		}
		else { //parent proccess-not waiting!
			return 1; 
		}
	}
	else {	//"normal" command-any other command
			sig.sa_handler = &sigHand;
			if (sigaction(SIGINT,&sig,&old) < 0) {
				printf("error with signal : %s\n",strerror(errno));
				return 0;
			}
			child=fork();
			if (child < 0) {
				printf("fork failed : %s\n",strerror(errno));
				return 0;
			}
			if (child == 0) { //child proceess-runing the command
				execvp(*arglist,arglist);
				printf("execvp failed : %s\n",strerror(errno));
				return 0;
			}
			else {  //parent proccess-waiting for the command,and ignore SIGINT
				int status; 
				sig.sa_handler=SIG_IGN;
				if (sigaction(SIGINT,&sig,NULL) < 0) {
					printf("error with signal : %s\n",strerror(errno));
					return 0;
				}
				if (wait(&status) < 0) {
					printf("error with wait 2 : %s\n",strerror(errno));
					return 0;
				}
				//restore the previous signal handler
				if (sigaction(SIGINT,&old,NULL) < 0) {
					printf("error with signal : %s\n",strerror(errno));
					return 0;
				}
				return 1;

			}

	}
}